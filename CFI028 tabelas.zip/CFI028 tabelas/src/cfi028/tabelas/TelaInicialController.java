package cfi028.tabelas;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;


public class TelaInicialController implements Initializable {
  
  @FXML
  private TextField txtNome;
  @FXML
  private TextField txtSalario;
  @FXML
  private Spinner<Integer> spNumDependentes;
  @FXML
  private Button btnSalvar;
  @FXML
  private TableView<Funcionarios> tblFuncionarios;
  @FXML
  private TableColumn<Funcionarios, String> colNome;
  @FXML
  private TableColumn<Funcionarios, Integer> colNumDependentes;
  @FXML
  private TableColumn<Funcionarios, Double> colSalario;
  ObservableList<Funcionarios> listaFuncionarios = FXCollections.observableArrayList();
//  String nome;
 // Integer numDependentes;
//] Double salario;
  
  @Override
  public void initialize(URL url, ResourceBundle rb) {
   colNome.setCellValueFactory(new PropertyValueFactory("nome"));
   colNumDependentes.setCellValueFactory(new PropertyValueFactory("numDependentes"));
   colSalario.setCellValueFactory(new PropertyValueFactory("salario"));
   tblFuncionarios.setItems(listaFuncionarios);
   tblFuncionarios.setOnMouseClicked(event -> clicarTabela(event));
   SpinnerValueFactory numDependentes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,25,0);
   spNumDependentes.setValueFactory(numDependentes);
   // teste de evento onKeyPressed
   txtNome.setOnKeyPressed(event -> digitarTxtNome(event));
  }  

  
   public void digitarTxtNome(KeyEvent event){
     System.out.println("t");
     
   }
  @FXML
  private void handleButtonActionSalvar(ActionEvent event) {
    String nome;
    Integer numDependentes;
    Double salario;
    try {
    
      nome = txtNome.getText();
      salario = Double.parseDouble(txtSalario.getText());
      numDependentes = spNumDependentes.getValue();
      
      Funcionarios f = new Funcionarios(nome, numDependentes, salario);
      listaFuncionarios.add(f);
      limpar();
      
    } catch (Exception e) {
      System.out.println("ERRO");
    }
   }
 
  public void limpar(){
    txtNome.clear();
    txtSalario.clear();
    spNumDependentes.getValueFactory().setValue(0);
  }

  public void clicarTabela(MouseEvent event){
    int posicao = tblFuncionarios.getSelectionModel().getSelectedIndex();
    Funcionarios f = tblFuncionarios.getSelectionModel().getSelectedItem();
    txtNome.setText(f.getNome());
    spNumDependentes.getValueFactory().setValue(f.getNumDependentes());
    txtSalario.setText(String.valueOf(f.getSalario()));
  }
}
