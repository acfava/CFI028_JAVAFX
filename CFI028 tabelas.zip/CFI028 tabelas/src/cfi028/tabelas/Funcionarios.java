/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cfi028.tabelas;

/**
 *
 * @author Usuario
 */
public class Funcionarios {
  String nome;
  Integer numDependentes;
  Double salario;

  public String getNome() {
    return nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public Integer getNumDependentes() {
    return numDependentes;
  }

  public void setNumDependentes(Integer numDependentes) {
    this.numDependentes = numDependentes;
  }

  public Double getSalario() {
    return salario;
  }

  public void setSalario(Double salario) {
    this.salario = salario;
  }

  public Funcionarios(String nome, Integer numDependentes, Double salario) {
    this.nome = nome;
    this.numDependentes = numDependentes;
    this.salario = salario;
  }

  public Funcionarios() {
  }
  
}
