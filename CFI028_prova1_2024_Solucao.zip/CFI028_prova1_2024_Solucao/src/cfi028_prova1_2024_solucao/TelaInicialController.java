/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package cfi028_prova1_2024_solucao;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

public class TelaInicialController implements Initializable {

    private Label label;
    @FXML
    private Button btnFechar;
    @FXML
    private TextField txtNome;
    @FXML
    private TextField txtData;
    @FXML
    private TextField txtPeso;
    @FXML
    private ComboBox<String> cbTipos;
    @FXML
    private CheckBox chkPenta;
    @FXML
    private CheckBox chkMeningite;
    @FXML
    private CheckBox chktriplice;
    @FXML
    private CheckBox chkpneumo;
    @FXML
    private Button btnCadastrar;
    @FXML
    private ListView<Vacinas> lstVacinas;
    @FXML
    private RadioButton rdpix;
    @FXML
    private RadioButton rbcartao;
    @FXML
    private RadioButton rbboleto;
    @FXML
    private Button btnapagar;
    @FXML
    private Button btncalcular;
    @FXML
    private Label lbltotal;
    @FXML
    private Label lblsemdesc;
    @FXML
    private Label lblcomdesc;
    @FXML
    private ToggleGroup tgPagamento;

    ObservableList<Vacinas> obsvacinas = FXCollections.observableArrayList();
    Double preco = 0.0;
    Double precodesc = 0.0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        inicializa();
    }

    @FXML
    private void btnFecharClick(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void btnCadastrarClick(ActionEvent event) {
     preco=0.0;
        String nome = txtNome.getText();
        if (!nome.isEmpty()) {
            String data = txtData.getText();
            Double peso = Double.parseDouble(txtPeso.getText());
            String  texto="Vacinas: ";
            int vacinatomadas = 0;
            int posicao = cbTipos.getSelectionModel().getSelectedIndex();
            String sexo = cbTipos.getSelectionModel().getSelectedItem();
            RadioButton rbPag = (RadioButton) tgPagamento.getSelectedToggle();
            texto = texto + sexo ;
            
            texto = texto + peso;
                if (chkMeningite.isSelected()) {
                    vacinatomadas += 1;
                    preco = preco + 420;
                    texto = texto + " Meningite, \n";

                }
                if (chkPenta.isSelected()) {
                    vacinatomadas += 1;
                    preco = preco + 320;
                    texto = texto + " Pentavalente, \n";

                }
                if (chkpneumo.isSelected()) {
                    vacinatomadas += 1;
                    preco = preco + 320;
                    texto = texto +  " Pneumo, \n";
                }
                if (chktriplice.isSelected()) {
                    vacinatomadas += 1;
                    preco = preco + 150;
                    texto = texto +  " Triplice";;
                }
                
                if (rdpix.isSelected()) {
                    precodesc = preco * 0.90;
                 
                }
                if (rbcartao.isSelected()) {
                    precodesc = preco;
                }
                if (rbboleto.isSelected()) {
                    precodesc = preco*0.95;
                }
              
                String pag = rbPag.getText();
                ;
                Vacinas v = new Vacinas(nome, texto, peso, vacinatomadas, preco, precodesc);
                obsvacinas.add(v);
                lblcomdesc.setText(String.format("%.2f", precodesc));
                lblsemdesc.setText(String.format("%.2f", preco));
            
        } else {
            alerta("Revise os dados");
        }

    }

    @FXML
    private void btnapagarclick(ActionEvent event) {
        int posicao = lstVacinas.getSelectionModel().getSelectedIndex();
        if (posicao >= 0) {
            obsvacinas.remove(posicao);
        }
    }

    @FXML
    private void btncalcularclick(ActionEvent event) {
        Double soma = 0.0;
        for (Vacinas v : obsvacinas) {
            soma = soma + v.getPrecoreal();
        }
        lbltotal.setText(String.format("%.2f", soma));
    }

    public void inicializa() {
        lstVacinas.setItems(obsvacinas);
        cbTipos.getItems().addAll("Masculino", "Feminino");
        cbTipos.getSelectionModel().selectFirst();
        txtNome.requestFocus();
        tgPagamento = new ToggleGroup();
        rdpix.setToggleGroup(tgPagamento);
        rbboleto.setToggleGroup(tgPagamento);
        rbcartao.setToggleGroup(tgPagamento);
        rdpix.setSelected(true);
    }

    public void alerta(String mensagem) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("ERRO");
        alerta.setContentText(mensagem);
        alerta.showAndWait();

    }
}
