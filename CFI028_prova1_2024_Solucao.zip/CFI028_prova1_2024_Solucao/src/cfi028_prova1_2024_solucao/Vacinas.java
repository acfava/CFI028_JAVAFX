/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cfi028_prova1_2024_solucao;

/**
 *
 * @author Aluno
 */
public class Vacinas {

    String nome;
    String texto;
    Double peso;
    int vacinastom;
    Double precoreal;
    Double precodesconto;

    public Vacinas() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public Double getPeso() {
        return peso;
    }

    public void setPeso(Double peso) {
        this.peso = peso;
    }

    public int getVacinastom() {
        return vacinastom;
    }

    public void setVacinastom(int vacinastom) {
        this.vacinastom = vacinastom;
    }

    public Double getPrecoreal() {
        return precoreal;
    }

    public void setPrecoreal(Double precoreal) {
        this.precoreal = precoreal;
    }

    public Double getPrecodesconto() {
        return precodesconto;
    }

    public void setPrecodesconto(Double precodesconto) {
        this.precodesconto = precodesconto;
    }

    @Override
    public String toString() {
        return  nome +  ", Qtd Vacinas=" + vacinastom + ", peso=" + peso + ", Sexo=" + texto + "\n Preco=" + precoreal + ", \tCom Desconto=" + precodesconto;
    }

    public Vacinas(String nome, String texto, Double peso, int vacinastom, Double precoreal, Double precodesconto) {
        this.nome = nome;
        this.texto = texto;
        this.peso = peso;
        this.vacinastom = vacinastom;
        this.precoreal = precoreal;
        this.precodesconto = precodesconto;
    }

    
  
}
