/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cfi028_2019_tabelas2;

/**
 *
 * @author Usuario
 */
public class Funcionarios {
 String nome;
 Integer numDependentes;
 Double Salario;

 public Funcionarios() {
 }

 public Funcionarios(String nome, Integer numDependentes, Double Salario) {
  this.nome = nome;
  this.numDependentes = numDependentes;
  this.Salario = Salario;
 }

 public String getNome() {
  return nome;
 }

 public void setNome(String nome) {
  this.nome = nome;
 }

 public Integer getNumDependentes() {
  return numDependentes;
 }

 public void setNumDependentes(Integer numDependentes) {
  this.numDependentes = numDependentes;
 }

 public Double getSalario() {
  return Salario;
 }

 public void setSalario(Double Salario) {
  this.Salario = Salario;
 }
 
 
}
