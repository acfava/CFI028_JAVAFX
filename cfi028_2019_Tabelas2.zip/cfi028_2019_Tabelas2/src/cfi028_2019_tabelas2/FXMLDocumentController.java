/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cfi028_2019_tabelas2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

/**
 *
 * @author g11
 */
public class FXMLDocumentController implements Initializable {

 @FXML
 private Label label;
 @FXML
 private Button btnAdicionar;
 @FXML
 private TableView<Funcionarios> tabela;


 @FXML
 private TableColumn<Funcionarios, String> colNome;
 @FXML
 private TableColumn<Funcionarios, Integer> colNumDependentes;
 @FXML
 private TableColumn<Funcionarios, Double> colSalario;
 @FXML
 private TextField txtNome;
 @FXML
 private TextField txtNumDependentes;
 @FXML
 private TextField txtSalario;
 
  final ObservableList<Funcionarios> obsFunc = FXCollections.observableArrayList();

 
 @Override
 public void initialize(URL url, ResourceBundle rb) {
  tabela.setItems(obsFunc);
  // definindo quis atributos da classe funcionarios serão mostrados em cad coluna
 // colNome.setCellValueFactory(new PropertyValueFactory("Nome"));
//  colNumDependentes.setCellValueFactory(new PropertyValueFactory("numDependentes"));
 // colSalario.setCellValueFactory(new PropertyValueFactory("salario"));
  
  //outra forma de definir quais atributos da classe funcionarios vao ser mostradas nas colunas
  colNome.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNome()));
  colNumDependentes.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getNumDependentes()).asObject());
  colSalario.setCellValueFactory(data -> new SimpleDoubleProperty(data.getValue().getSalario()).asObject());
  
  

  // TODO
 }



 @FXML
 private void btnAdicionarClick(ActionEvent event) {
   try {
   String nome = txtNome.getText();
  Integer numDependentes = Integer.parseInt(txtNumDependentes.getText());
  Double Salario = Double.parseDouble(txtSalario.getText());
   Funcionarios f = new Funcionarios(nome, numDependentes,Salario);
   obsFunc.add(f);
   
  } catch (Exception e) {
   System.out.println("Erro na entrada de dados");
  }
 
 }


}
