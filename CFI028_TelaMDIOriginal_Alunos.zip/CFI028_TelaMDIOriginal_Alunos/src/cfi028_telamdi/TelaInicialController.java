/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cfi028_telamdi;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class TelaInicialController implements Initializable {

  @FXML
  private MenuItem menuItemClientes;
  @FXML
  private AnchorPane anchorPane;
  @FXML
  private ImageView imgLogo;
  @FXML
  private MenuItem menuItemTelaInicial;
 // criando um archorpane para copiar a tela inicial, e depois ser restaurada
  private AnchorPane reserva;

  @Override
  public void initialize(URL url, ResourceBundle rb) {
// salvando o arnchorpane da tela inicial
    reserva = new AnchorPane();
    reserva.getChildren().addAll(anchorPane.getChildren());
  }

  @FXML
  private void handleMenuItemClientesAction(ActionEvent event) {
    try {
      AnchorPane a = (AnchorPane) FXMLLoader.load(getClass().getResource("/view/TelaClientes.fxml"));
      anchorPane.getChildren().setAll(a);
    } catch (Exception e) {
      System.out.println("Erro ao carregar a página CLIENTES");
    }
  }



  @FXML
  private void handleMenuItemmenuItemTelaInicialAction(ActionEvent event) {
    // restaurando o anrchorpane inicial na tela
    anchorPane.getChildren().setAll(reserva.getChildren());
  }
}
