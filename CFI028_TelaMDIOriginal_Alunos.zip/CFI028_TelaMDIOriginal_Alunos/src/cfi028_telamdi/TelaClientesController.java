/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cfi028_telamdi;

import model.Clientes;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

public class TelaClientesController implements Initializable {

  @FXML
  private TableView<Clientes> tblClientes;
  @FXML
  private TextField txtCodigo;
  @FXML
  private TextField txtNome;
  @FXML
  private TextField txtEmail;
  @FXML
  private Button btnCadastrar;
  @FXML
  private Button btnApagar;
  @FXML
  private Button btnLimpar;

  ObservableList<Clientes> obsClientes   = FXCollections.observableArrayList();

  /**
   Código para um cadastro simples de clientes usando apenas observablelist, sem persistencia de banco de dados
  
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    inicializarTabela();
    tblClientes.setOnMouseClicked(event -> clicarTabela(event));
    txtCodigo.setOnKeyPressed(event -> teclarTxtCodigo(event));
    adicionarFocusListener();
  }

  @FXML
  private void handlebtnCadastrarAction(ActionEvent event) {
    Clientes c = new Clientes(Integer.parseInt(txtCodigo.getText()),
     txtNome.getText(),
     txtEmail.getText());
    obsClientes.add(c);
    limpar();
  }

  @FXML
  private void handlebtnApagarAction(ActionEvent event) {
    // le um cliente da tabela. Se tem algum selecionado, apaga do observable list
    Clientes selectedCliente = tblClientes.getSelectionModel().getSelectedItem();
    if (selectedCliente != null) {
      obsClientes.remove(selectedCliente);
      limpar();
    }
  }

  @FXML
  private void handlebtnLimparAction(ActionEvent event) {
    limpar();
  }

  public void inicializarTabela() {
    obsClientes.addAll(
     new Clientes(32, "William", "william@email.com"),
     new Clientes(17, "Luana", "luana@email.com"),
     new Clientes(12, "Maria", "maria@email.com"),
     new Clientes(15, "João", "joao@email.com"),
     new Clientes(28, "Antônio", "antonio@email.com"),
     new Clientes(17, "Teles", "teles@email.com"),
     new Clientes(30, "Eduan", "eduan@email.com"),
     new Clientes(22, "Gabu", "gabu@email.com")
    );
    // criando os tableCOlum via codigo, sem criar pelo SceneBuilder
    TableColumn colunaCodigo = new TableColumn<>("Código");
    TableColumn colunaNome = new TableColumn<>("Nome");
    TableColumn colunaEmail = new TableColumn<>("E-mail");

    //associar a classe cliente às minhas colunas.
    // usar o nome dos atributos da classe cliente IGUAIZINHOS
    colunaCodigo.setCellValueFactory(new PropertyValueFactory<>("codigo"));
    colunaNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
    colunaEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
    // inserindo as colunas na tblClientes
    tblClientes.getColumns().addAll(colunaCodigo, colunaNome, colunaEmail);
    tblClientes.setItems(obsClientes);
  }

  public void clicarTabela(MouseEvent event) {
    Clientes c = tblClientes.getSelectionModel().getSelectedItem();
    if (c != null) {
      txtCodigo.setText(Integer.toString(c.getCodigo())); // integer.toString é igual ao String.ValueOf
      txtNome.setText(c.getNome());
      txtEmail.setText(c.getEmail());
    }
  }
// evento que testa se teclor ENTER, para ir para proximo campo
  public void teclarTxtCodigo(KeyEvent event) {
    if (event.getCode().equals(KeyCode.ENTER)) {
      String codigo = txtCodigo.getText();
      if (codigo.length() < 2) {
        alerta("campo obrigatorio: minimo dois digitos!");
        txtCodigo.requestFocus();
      } else {
        txtNome.requestFocus();
      }
    }
  }
// evento que ao sair do txtCodigo, testa se tem minimo de dois digitos
  private void adicionarFocusListener() {
    txtCodigo.focusedProperty().addListener((observable, oldValue, newValue) -> {
      if (!newValue) { // Se o txtCodigo perdeu o foco
        String codigo = txtCodigo.getText().trim();
        if (codigo.length() < 2) {
          alerta("campo obrigatorio: minimo dois digitos!");
          txtCodigo.requestFocus();
        } else {
          txtNome.requestFocus();
        }
      }
    });
  }
// limpa os campos
  public void limpar() {
    txtCodigo.clear();
    txtNome.clear();
    txtEmail.clear();
    txtCodigo.requestFocus();
  }
//mnesagem de alerta, recebe mensagem e exibe alerta
  public void alerta(String mensagem) {
    Alert a = new Alert(Alert.AlertType.NONE);
    a.setAlertType(Alert.AlertType.ERROR);
    // set content text
    a.setContentText(mensagem);
    a.setHeaderText("Erro");
    // show the dialog
    a.show();
  }
}
