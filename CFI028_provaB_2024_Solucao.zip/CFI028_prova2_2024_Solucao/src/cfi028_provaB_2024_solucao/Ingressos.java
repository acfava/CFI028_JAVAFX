package cfi028_provaB_2024_solucao;
public class Ingressos {
    String Nome;
    int Idade;
    String tipoIngresso, Adicionais, Cadeira;
    double Valor;

    @Override
    public String toString() {
        return Nome + ", Idade=" + Idade + ", Tipo do Ingresso="+ tipoIngresso
         + "\nAdicionais=" + Adicionais + "\nCadeira=" + Cadeira + "\nValor=" + Valor;
    }

    public Ingressos() {
    }

    public Ingressos(String Nome, int Idade, String tipoIngresso, String Adicionais, String Cadeira, double Valor) {
        this.Nome = Nome;
        this.Idade = Idade;
        this.tipoIngresso = tipoIngresso;
        this.Adicionais = Adicionais;
        this.Cadeira = Cadeira;
        this.Valor = Valor;
    }

    public double getValor() {
        return Valor;
    }

    public void setValor(double Valor) {
        this.Valor = Valor;
    }
    
    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public int getIdade() {
        return Idade;
    }

    public void setIdade(int Idade) {
        this.Idade = Idade;
    }

    public String getTipoIngresso() {
        return tipoIngresso;
    }

    public void setTipoIngresso(String tipoIngresso) {
        this.tipoIngresso = tipoIngresso;
    }

    public String getAdicionais() {
        return Adicionais;
    }

    public void setAdicionais(String Adicionais) {
        this.Adicionais = Adicionais;
    }

    public String getCadeira() {
        return Cadeira;
    }

    public void setCadeira(String Cadeira) {
        this.Cadeira = Cadeira;
    }
    
}
