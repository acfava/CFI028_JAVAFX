package cfi028_provaB_2024_solucao;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.function.UnaryOperator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

public class TelaInicialController implements Initializable {

 @FXML
 private TextField txtNome;
 @FXML
 private Button btnCadastrar;
 @FXML
 private Button btnFechar;
 @FXML
 private ComboBox<String> cbTipos;
 @FXML
 private ListView<Ingressos> lstVendas;
 @FXML
 private TextField txtIdade;
 @FXML
 private CheckBox chkPipoca;
 @FXML
 private CheckBox chkRefri;
 @FXML
 private CheckBox chkSuco;
 @FXML
 private CheckBox chkChoco;
 @FXML
 private RadioButton rbCadeiraComum;
 @FXML
 private RadioButton rbCadeiraEspecial;
 @FXML
 private RadioButton rbCadeiraLuxo;
 @FXML
 private Label lblValorPagar;
 @FXML
 private Label lblTotal;
 @FXML
 private ToggleGroup tgCadeiras;

 Double Valor = 0.0;
 ObservableList<Ingressos> obsIngressos = FXCollections.observableArrayList();
 Double[] ValorIngresso = {25.0, 50.0, 0.0};
 @FXML
 private Button btnFechamento;
 @FXML
 private Button btnApagar;

 @Override
 public void initialize(URL url, ResourceBundle rb) {
  inicializaComponentes();
 }

 @FXML
 private void btnCadastrarClick(ActionEvent event) {
  try {
   Valor = 0.0;

   if (!txtNome.getText().isEmpty()) {
    String Nome = txtNome.getText();
    int Idade = Integer.valueOf(txtIdade.getText());
    int posicao = cbTipos.getSelectionModel().getSelectedIndex();

    RadioButton rbDesconto = (RadioButton) tgCadeiras.getSelectedToggle();
    String Cadeira = rbDesconto.getText();
    Valor += ValorIngresso[posicao];
    String Adicionais = "";
    String tipoIngresso = cbTipos.getValue().toUpperCase();
    if (chkPipoca.isSelected()) {
     Valor += 32.0;
     Adicionais += "Pipoca, ";
    }
    if (chkRefri.isSelected()) {
     Adicionais += "Refrigerante, ";
     Valor += 20.0;
    }
    if (chkSuco.isSelected()) {
     Adicionais += "Suco, ";
     Valor += 25.00;
    }
    if (chkChoco.isSelected()) {
     Adicionais += "Chocolates ";
     Valor += 15.00;
    }

    int index = tgCadeiras.getToggles().indexOf(rbDesconto);
    if (index == 0) {
     Valor += 10;
    }
    if (index == 2) {
     Valor += 25;
    }
    Ingressos i = new Ingressos(Nome, Idade, tipoIngresso, Adicionais, Cadeira, Valor);
    obsIngressos.add(i);
    lblValorPagar.setText("R$ " + String.format("%.2f", Valor));
    btnFechamentoClick(event);
   
  }else {
    alerta("O campo NOME não pode ser vazio");
   }
 }
 catch (NumberFormatException e) {
   // Caso a entrada seja inválida, exibe uma mensagem de erro
   alerta("Valor inválido. Verifique a entrada dos dados novamente");
  txtIdade.requestFocus();
 }
}

 @FXML
 private void btnApagarClick(ActionEvent event) {
  int posicao = lstVendas.getSelectionModel().getSelectedIndex();
        if (posicao >= 0) {
            obsIngressos.remove(posicao);
            btnFechamentoClick(event);
      
        }
  }
 
  


 public void inicializaComponentes() {
  UnaryOperator<TextFormatter.Change> filtro = change -> {
   String newText = change.getControlNewText();
   if (newText.matches("-?([0-9]*)\\.?([0-9]*)")) {
    return change;
   }
   return null;
  };
  TextFormatter<String> textoFormatado = new TextFormatter<>(filtro);
  txtIdade.setTextFormatter(textoFormatado);

  // faz o "casamento" do observablelist com o listview
  lstVendas.setItems(obsIngressos);
  // carrega o combobox com os sabores de pizza
  cbTipos.getItems().addAll("Meia", "Inteira", "Cortesia");
  

 }

 public void alerta(String mensagem) {
  Alert alerta = new Alert(Alert.AlertType.ERROR);
  alerta.setTitle("ERRO");
  alerta.setContentText(mensagem);
  alerta.showAndWait();
 }


 @FXML
 private void btnFecharClick(ActionEvent event) {
  System.exit(0);
 }


 @FXML
 private void btnFechamentoClick(ActionEvent event) {
   String ultimaCadeira = "";
  Double ValorTotal = 0.0;
  for (Ingressos i : obsIngressos) {
   ValorTotal += i.getValor();
   ultimaCadeira = i.getCadeira();
  }
  lblTotal.setText("R$ " + String.format("%.2f", ValorTotal));
 }
}
